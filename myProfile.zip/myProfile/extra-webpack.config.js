const path = require('path');

module.exports = {
    resolve: {
        extensions: ['.js'],
        fallback: {
            "crypto": require.resolve("crypto-browserify"),
            "https": require.resolve("https-browserify"),
            "http": require.resolve("stream-http"),
            "tls": false,
            "net": false,
            "assert": false
        },
        alias: {
            path: require.resolve("path-browserify"),
            fs: path.resolve(__dirname, 'src/mocks/fs.mock.js'),
            child_process: path.resolve(
                __dirname,
                'src/mocks/child_process.mock.js'
            )
        },
    },
};