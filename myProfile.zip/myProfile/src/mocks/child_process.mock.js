module.exports = {
    readFileSync() { },
    readFile() { },
};